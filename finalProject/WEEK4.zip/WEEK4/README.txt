CG project:
Submission 4

Week4 updates:
1. Ground added
2. Grass texture on ground
3. Auto Camera Rotation

There are checkboxes, respectively for enabling (or disabling) features:
	Ambient light (Switched on by default)
	Directional light
	Auto-rotate
	Shear (Along XY, YZ and ZX (can be set individually))
	Orthographic and Perspective camera option (Radio buttons)

Mouse controls
	Scene Rotation/Orbit: Left click and drag
	Translation: Right click and drag
	Zoom in/out: Scroll

Libraries: THREE.js (over WebGL), Bootstrap

Use Firefox, Chrome or Safati (old browsers might not support
WebGL.)
https://caniuse.com/#feat=webgl

Three.js is a cross-browser JavaScript library available under the MIT license.
Source code of this library has been modified to better suit the needs of this project.