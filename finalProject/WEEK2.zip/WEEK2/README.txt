CG project:
Submission 2

There are checkboxes, respectively for enabling (or disabling) features:
	Ambient light (Switched on by default)
	Directional light
	Auto-rotate
	Shear (Along XY, YZ and ZX (can be set individually))
	Orthographic and Perspective camera option (Radio buttons)

Mouse controls
	Rotation/Orbit: Left click and drag
	Translation: Right click and drag
	Zoom in/out: Scroll

Libraries: THREE.js (over WebGL), Bootstrap

Use Firefox, Chrome or Safati (old browsers might not support
WebGL.)
https://caniuse.com/#feat=webgl