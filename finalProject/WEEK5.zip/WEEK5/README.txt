CG project:
Submission 5

Week5 updates:
1. Merged a quad pyramid (roof) and with the previous structure.
2. Option to resize house width and breadth.
	2.1 Resize house size from the side view and front view window.
	2.2 Side, front and top views reflect the actual dimension of the house.

There are checkboxes, respectively for enabling (or disabling) features:
	Ambient light (Switched on by default)
	Directional light
	Auto-rotate
	Shear (Along XY, YZ and ZX (can be set individually))
	Orthographic and Perspective camera option (Radio buttons)

Mouse controls
	Scene Rotation/Orbit: Left click and drag
	Translation: Right click and drag
	Zoom in/out: Scroll

Size controls
	Click on the side view or front view canvases to resize along the X or Z axis.

Libraries: THREE.js (over WebGL), Bootstrap

Use Firefox, Chrome or Safati (old browsers might not support
WebGL.)
https://caniuse.com/#feat=webgl

Three.js is a cross-browser JavaScript library available under the MIT license.
Source code of this library has been modified to better suit the needs of this project.