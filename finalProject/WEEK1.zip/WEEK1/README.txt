CG project:
Submission 1

Progress Achieved Hitherto:
	- basic 3D cube implemented
	- Perspective camera (near plane: 0.1, far plane: 1000)
	- 3D Transformations:
		- Translation (use keyboard arrows)
		- Rotation (use mouse to click and drag)
		- scroll to move closer
		(-Auto-rotate check box)
	Lighting:
		- ambient lighting
		- directional lighting
		(- Basic shading and Phong shading)

Libraries: THREE.js (over WebGL)

Use Firefox, Chrome or Safati (old browsers might not support
WebGL.)
https://caniuse.com/#feat=webgl